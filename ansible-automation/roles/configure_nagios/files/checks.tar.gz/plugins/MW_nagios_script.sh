#!/bin/bash
#-----------------------------------------------------------------------------------------------
# Filename: MW_nagios_script.sh
#
# Classification: Unclassified
#
# Purpose:
# This script provides status of the MW-% systems to NAGIOS.  This script is called from NAGIOS
# (controlled by the SEMS SysAdmin team).  This script compiles information based on the "mwstatus -N" command 
# and creates a message and return status that is returned to NAGIOS (the calling routine).
#
# This script takes one argument:
# 1. MW Instance name: $REMOTEHOST, ("mw-a" "mw-b" or "mw-c")
# It looks for a filename in the current directory called afw-$REMOTEHOST.mwstatus.
# The afw-$REMOTEHOST.mwstatus file is created by a crontab script called mwstatus_script.sh
#
# Output from this script is a single message and a return status value
# 
# CHANGE HISTORY:
# Date       CR#             Engineer        Description
# -----------------------------------------------------------------------------------------------
# 14Nov2018  WDD-4151        K. Nye          Re-purposed the existing MW_appman_script.sh
#                                            script for the transition to NAGIOS.  Much of this
#                                            script is used "as is" and only the needed mods 
#                                            were made to return a single message and status
#                                            to the NAGIOS calling script.
#
# 08Oct2019  WDD-6711        Jerry (Khoa Le) Update the script to work with Moving Weather v1.8.2 
# -----------------------------------------------------------------------------------------------
#
usage()
{
   echo "Usage: MW_nagios_script.sh mw-a|mw-b|mw-c"
   exit 1;
}

#MAIN
#Hostname to check is argument.  If no argument, exit.
case $# in
   1)
      case $1 in
         mw-a|mw-b|mw-c)
            REMOTEHOST=$1;
            ;;
         *)
            usage;
            ;;
      esac
      ;;
   *)
      usage;
      ;;
esac

#Create the output file which will be checked in later processing
OUTPUTDIR=/tmp
MW_STATUS_FILE=$OUTPUTDIR/afw-${REMOTEHOST}.mwstatus
. /home/${REMOTEHOST}/.bashrc > /dev/null
#Get the output of mwstatus -N and put it into OUTPUT_STR var quietly. Do this so it does not print anything to the command line.
#If we just write the output to a file then it will print extra line about Moving Weather to the command line.
OUTPUT_STR=$(($MWDIR/bin/mwstatus -N) 2>&1)
`echo "$OUTPUT_STR" | egrep "PROCESS_SERVICE_CHECK_RESULT" | cut -f 1,2,3,4,5 -d ';' > $MW_STATUS_FILE`
chmod 644 $MW_STATUS_FILE

ERRORFLAG=0
SEVERITY="I"
ERRORS=""

# The first thing we do is parse through all of the status output and create separate lines for each of the 5 error types
# The 5 error types are
#       CHANNELS
#       PROCESSES
#       DISK
#       FILES
#       UNKNOWN (anything else that is output that does not match one of the other 4 types).

#Get Channel Status info for bad channels only (ignore 0 status). Remove some unnecessarry info and formatting
CHECK_CHANNELS=`grep 'mw.lcn' ${MW_STATUS_FILE} |egrep -v 'mw\.lcn[0-9]{3}\.[0-9]{3};0;'| sed '{s/'CCCC=\'\',\ '//g}' | sed '{s/'\''//g}'`

#Get processes status (ignore 0 status).
PROCESSES_LINE=`egrep "mw.processes" ${MW_STATUS_FILE}`
CHECK_PROCESSES=`echo "${PROCESSES_LINE}" |egrep -v "mw.processes;0" |cut -f 3,5 -d ';' --output-delimiter=" is status " | sed '{:q;N;s/\n/\\\n/g;t q}'|sed 's/, /\\\n/g' |sed 's/CRASHED?.//g' `
CHECK_PROCESSES2=`echo -e ${CHECK_PROCESSES}|egrep -v "\(.*\)$"`

#Get disk usage status (ignore 0 status).
DISK_LINE=`egrep "mw.db.status.disk.usage" ${MW_STATUS_FILE}`
CHECK_DISK=`echo "${DISK_LINE}" | sed "s/:\/var\/\${REMOTEHOST}//g" | egrep -v "mw.db.status.disk.usage;0" |cut -f 3,5 -d ';' --output-delimiter=" is status " | sed '{:q;N;s/\n/\\\n/g;t q}'|sed 's/, /\\\n/g' |sed 's/CRASHED?.//g' `

#Get files status (ignore 0 status).
FILES_LINE=`egrep "mw.files" ${MW_STATUS_FILE}`
CHECK_FILES=`echo "${FILES_LINE}" |egrep -v "mw.files;0" |cut -f 3,5 -d ';' --output-delimiter=" is status " | sed '{:q;N;s/\n/\\\n/g;t q}'|sed 's/, /\\\n/g' |sed 's/CRASHED?.//g' `
   
#Consolidate all other unknown status info into a single line, if any.
UNKNOWN=`egrep -v "mw.processes|mw.lcn|mw.db.status.disk.usage|mw.files" ${MW_STATUS_FILE} | cut -f 3,5 -d ';' --output-delimiter=" is status " | sed '{:q;N;s/\n/,/g;t q}'`
   
# The rest of this script basically looks to see which parts have info (meaning a bad status of some kind) and builds a single line based on what we have.
# This is put into a single line called $ERRORS
#Note:  If only channels report bad, the message will contain info to contact SYSD.
#       If anything else reports bad (regardless of channel status), the message will contain info to contact WDD
   
# First off, we will check to see if we have any bad status by checking if any of the values contain info.
# if any contain info, set the severityflag and errorflag values to contain "error status".
# if the only error is for CHANNELS, then we assign the contact line to be SYSD Data routing
if [ ${#CHECK_PROCESSES2} -gt "0" ] || [ ${#CHECK_CHANNELS} -gt "0" ] || [ ${#CHECK_DISK} -gt "0" ] || [ ${#CHECK_FILES} -gt "0" ] ||[ ${#UNKNOWN} -gt "0" ];
then
   ERRORFLAG=2
   SEVERITY="C"
   ERRORS="CRITICAL on ${REMOTEHOST} instance: Contact WDD at 402-680-6120 with the following information:";
   if [ ${#CHECK_CHANNELS} -gt "0" ] && [ ${#CHECK_PROCESSES2} -eq "0" ] && [ ${#CHECK_DISK} -eq "0" ] && [ ${#CHECK_FILES} -eq "0" ] && [ ${#UNKNOWN} -eq "0" ];
   then
      ERRORS="CRITICAL on ${REMOTEHOST} instance: Contact SYSD Data Routing with the following information:";
   fi
   
   # Since we now know we have errors, we will concatenate the individual types together based on those that contain bad status
   # Check to see if processes line contains bad status and format into a single line.
   if [ ${#CHECK_PROCESSES2} -gt "0" ]; then
      PROCESSES_RESULTS="The following process(es) on ${HOSTNAME} Moving Weather instance ${REMOTEHOST} have error conditions: \n${CHECK_PROCESSES2}. "
      ERRORS="${ERRORS}\n${PROCESSES_RESULTS}"
   fi

   #Check to see if channels line contains bad status and consolidate all the bad channels into a single status line.  
   if [ ${#CHECK_CHANNELS} -gt "0" ] ;then
      CHANNEL_RESULTS="The following channel(s) on ${HOSTNAME} Moving Weather instance ${REMOTEHOST} have error conditions: \nCHANNEL: `echo "${CHECK_CHANNELS}" |cut -f 3,5 -d ';' --output-delimiter=" is status " | sed '{:q;N;s/\n/CHANNEL: /g;t q}'|sed 's/CHANNEL:/\\\nCHANNEL:/g'`"
      ERRORS="${ERRORS}\n${CHANNEL_RESULTS}"
   fi
      
   #Check to see if CHECK_DISK line contains bad status and append into a single status line.  
   if [ ${#CHECK_DISK} -gt "0" ] ; then
      ERRORS="${ERRORS}\n${CHECK_DISK}"
   fi
   
   #Check to see if CHECK_FILES line contains bad status and append into a single status line.  
   if [ ${#CHECK_FILES} -gt "0" ] ; then
      ERRORS="${ERRORS}\n${CHECK_FILES}"
   fi
      
   #Check to see if UNKNOWN line contains bad status and append into a single status line.  
   if [ ${#UNKNOWN} -gt "0" ] ; then
      ERRORS="${ERRORS}\n${UNKNOWN}"
   fi
      
fi
RC=${ERRORFLAG};
# The Output to Nagios
#
# Message to send to Nagios
if [ ${RC} -eq "0" ]
then 
   echo -e "${SEVERITY} : ${REMOTEHOST} status = running"
else
   MSG=${ERRORS};
   echo -e ${SEVERITY} : ${MSG}
fi

# Exit with a status for Nagios
exit ${RC}
