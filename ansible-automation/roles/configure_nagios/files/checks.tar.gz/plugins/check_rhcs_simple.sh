#!/bin/bash
#
# Check RHCS
#
PATH=$PATH:/usr/sbin    # For RHEL5-RHEL6 Compatibility
ERRORS=
STATUS=
RC=
MYHOST=`hostname -s`
NOFAILOVER=/tmp/nofailover

# Certain Cluster Resources are defined, but permanently disabled because their prerequisites simply
# don't exixt in a given system or enclave.
# These resources can be permanently excluded. 
# The format of the excludes is as follows:
#         hostname  service_name
#         hostname  ALL   - disables all checks on a given host.
#                           This is  useful when the cluster rpm's are installed,
#                           yet the cluster services and configurations are under development.    
# The location of the file is defined here and is managed in Satellite.

CLUSTER_SERVICES_EXCLUDED=/usr/lib64/nagios/plugins/rhcluster_service.excludes

check_ricci(){
	RICCI_STATE=$(/etc/init.d/ricci status )

        ricci_status=$(/etc/init.d/ricci status $>/dev/null; echo $?)
        if [ $ricci_status -eq '0' ]
        then
                STATUS=$(echo -n "$STATUS"; echo -n "RICCI: RUNNING; ")
                RC_RICCI=0
                RC=$(echo -n "$RC"; echo -n "$RC_RICCI ")

        elif [ $ricci_status -gt '0' ]
        then
                ERRORS=$(echo -n "$ERRORS"; echo -n "$RICCI_STATE; ")
                RC_RICCI=1          # Set a Warning Alert
                RC=$(echo -n "$RC"; echo -n "$RC_RICCI ")
        fi
}




check_cluster() {

        CLUSTERINFO=$(cman_tool status | egrep 'Cluster Name:|Node name:|Node ID:' |awk -F: {'print $2'})
        CLUSTERINFO=$(echo "$CLUSTERINFO" | tr '\n' ' ')
        #
        # [0] = 'Cluster Name' [1] = 'Node name' [2] = 'Node ID'
        #
        declare -a CLUARRAY=($CLUSTERINFO)


}

check_rgmanager() {

        rgmstatus=$(clustat | egrep "$MYHOST" | egrep -v 'service:' | egrep 'rgmanager' | wc -l)
        if [ $rgmstatus -eq '1' ]
        then
                STATUS=$(echo -n "$STATUS"; echo -n "RGMANAGER: RUNNING; ")
                RC_RGMANAGER=0
                RC=$(echo -n "$RC"; echo -n "$RC_RGMANAGER ")

        elif [ $rgmstatus -lt '1' ]
        then
                ERRORS=$(echo -n "$ERRORS"; echo -n "RGMANAGER: NOT_RUNNING; ")
                RC_RGMANAGER=2            # Set a Critical Alert
                RC=$(echo -n "$RC"; echo -n "$RC_RGMANAGER ")
        fi
}


check_services() {

# Section added by Nathan Zingg 
      # Clear things out	
      unset EXCLUDELIST
      EXCLUDELIST=""
      unset SRVCARRAY
      SRVCARRAY=""
     
      # Some services defined for the sake of consistency, but intentionally disabled 
      # in a given enclave. 
      # The excluded services are loaded here. 
      EXCLUDELIST=$(cat $CLUSTER_SERVICES_EXCLUDED | grep -v "^#" | grep $MYHOST | awk '{print $2}'); 
      EXCLUDELIST=($EXCLUDELIST)

      # All the defined services are loaded here.		
      # SRVCARRAY=$(clustat | egrep 'service:' | awk -F: '{print $2}' | awk '{print $1}' )
      SRVCARRAY=$(clustat | egrep 'service:' | grep $MYHOST | awk -F: '{print $2}' | awk '{print $1}' )
      SRVCARRAY=($SRVCARRAY)

      # The comprehensive services list scrubbed of the excluded services
      for i in "${EXCLUDELIST[@]}"; do   SRVCARRAY=(${SRVCARRAY[@]//*$i*}); done

# Check for intentional excluded services
if [[ -z "${EXCLUDELIST[@]}" ]]; then
      EXCLUDED_TEXT="      No services intentionally excluded from check. "
else
      EXCLUDED_TEXT="      Service(s) intentionally excluded from check:  ${EXCLUDELIST[@]} "
fi

# Report a status if no services happen to be currently running on this host.
 
if [[ -z "${SRVCARRAY[@]}" ]]; then
      STATUS="No Cluster Services are currently running on this host." 
fi

         # check service is in 'running' state of the scrubbed list 
         for a in "${SRVCARRAY[@]}"
         do
                 svcstate=$(clustat -s $a | egrep 'service:' | awk {'print $NF'})
                 if [[ "$svcstate" =~ "started" ]]
                 then
                        STATUS=$(echo -n "$STATUS"; echo -n "$a : running; ")
                	RC_SERVICE=0
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 else
                        ERRORS=$(echo -n "$ERRORS"; echo -n "$a Error: $svcstate; ")
                	RC_SERVICE=1
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 fi

                 if [[ "$svcstate" =~ "failed" ]]
                 then
                	RC_SERVICE=2
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 fi     			 
                 
                 if [[ "$svcstate" =~ "disabled" ]]
                 then
                	RC_SERVICE=2
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 fi     			 
                 
                  if [[ "$svcstate" =~ "recoverable" ]]
                 then
                	RC_SERVICE=2
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 fi     			 
                 
                 if [[ "$svcstate" =~ "stopped" ]]
                 then
                	RC_SERVICE=2
                	RC=$(echo -n "$RC"; echo -n "$RC_SERVICE ")
                 fi 
        done
}




override_check() {

# Section added by Nathan Zingg
#
# Certain conditions require overrides of rigorous checks
#

      # Clear things out
      unset EXCLUDELIST
      EXCLUDELIST=""
      unset SRVCARRAY
      SRVCARRAY=""

#
# CONDITION 1
#
# On certain systems, the cluster rpm's are installed,
# yet the cluster services and configurations are still under development.
# Checks on these seems needs to overriden.
#
# The format of the overrides is as follows:
# 
#         hostname  ALL   - overrides all checks on a given host.
#                           This is  useful when the cluster rpm's are installed,
#                           yet the cluster services and configurations are under development.
# The location of the file is defined here and is managed in Satellite.
#

     if [[ $(cat $CLUSTER_SERVICES_EXCLUDED | grep -v "^#" | grep $MYHOST | awk '{print $2}' | grep -i ALL) ]]
        then
          STATUS="Cluster Check override in place for $MYHOST."
          EXCLUDED_TEXT="Clustered services under development."
          ERRORS=""
          RC_FINAL=0
     fi 

# End Condition 1 Section.     


#
# Condition 2
#
# If a nofailover is in place, disregard other status checks.
# If the nofailover file is >120 minues old, email notifications to the file owner will be sent.
# If the nofailover file is >240 minues old, nagios will additionally post a warning. 
#

     # Does a nofailover file exist?
     if [ -f $NOFAILOVER ]
        then
          # Info for email notifications
          TIMESTAMP=$(date)
          FILE_OWNER=$(ls -l $NOFAILOVER | awk '{print $3}')
          SUBJECT="Stale $NOFAILOVER file exists on $MYHOST"
          
          NOTICE="Dear User:                                                                                                          \
          \n                                                                                                                          \
          \n                                                                                                                          \
          \t A  $NOFAILOVER  file older than 120 minuntes owned by $FILE_OWNER on $MYHOST                                             \
          \n                                                                                                                          \
          \twas detected by Nagios on $TIMESTAMP.                                                                                     \
          \n                                                                                                                          \
          \n                                                                                                                          \
          \t The /tmp/nofailover file prevents the cluster from handling failure events properly.                                     \
          \n                                                                                                                          \
          \n                                                                                                                          \
          \t Please delete this file as soon as possible.                                                                             \
          \n                                                                                                                          \
          \n                                                                                                                          \
          V/r,                                                                                                                        \
          \n                                                                                                                          \
          - SEMS Sys Admins"
          
          EXCLUDED_TEXT="$EXCLUDED_TEXT"
          ERRORS=""
             
     # What do as the as the nofailover file ages.

             # Is the nofailover file more than 120 minutes old? 
             if [ $(find $NOFAILOVER -type f -mmin +120) ]
                then
		   # True - the nofailover file is > 120 minutes old, send the owner an e-mail
                   STATUS="Cluster Check $NOFAILOVER override in place for $MYHOST."
                   ERRORS="$NOFAILOVER - File Age > 120 min. Notifying file owner $FILE_OWNER."
                   echo -e $NOTICE | mail -s "$SUBJECT" $FILE_OWNER
                   RC_FINAL=0
                   SEVERITY="INFO"
                else
                   # False - the nofailover file is less than 120 minutes old. Assuming it is there for a good reason.
                   STATUS="Cluster Check $NOFAILOVER override in place for $MYHOST."
                   ERRORS="$NOFAILOVER - File Age OK."
                   RC_FINAL=0
                   SEVERITY="OK"
             fi

             if [ $(find $NOFAILOVER -type f -mmin +240) ]
                then
		   # True - the nofailover file is > 240 minutes old, now set Nagios alert to WARNING as well as the file owner email above. 
                   STATUS="Cluster Check $NOFAILOVER override in place for $MYHOST."
                   ERRORS="$NOFAILOVER - File Age > 240 min. Notifying file owner $FILE_OWNER."
                   RC_FINAL=1
                   SEVERITY="WARNING"
                else
		   # False - the nofailover file is < 240 minutes old. Take no additional acction.
                   STATUS=$STATUS
                   ERRORS=$ERRORS
                   RC_FINAL=$RC_FINAL
                   SEVERITY=$SEVERITY
             fi

     fi
 
# End Condition 2 Section.     

}


#
# Run the checks
#

check_ricci
check_cluster
check_rgmanager
check_services

#
# Evaluate the numerous checks of their highest return code.
#

RC_FINAL=$(echo $RC | sed -e "s/ /\n/g" | sort -n |  tail -1)

#
# Set an initial severity based on the return code. 0 = OK, 1 = Warning, 2 = Critical 
#
case $RC_FINAL in
	0 )
		SEVERITY="OK" ;;
	1 )
		SEVERITY="WARNING" ;;
	2 )
		SEVERITY="CRITICAL" ;;
esac


#echo initial severity $SEVERITY
#echo initial RC $RC_FINAL

override_check

#echo final severity $SEVERITY
#echo final RC $RC_FINAL

if [[ "$ERRORS" ]]
then
        echo "$SEVERITY: $ERRORS :: $STATUS"
#echo $RC_FINAL Errors
        exit $RC_FINAL
else
#echo $RC_FINAL NO Errors
        echo "OK: $STATUS"
        echo "$EXCLUDED_TEXT"
        exit $RC_FINAL
fi

