# Export HISTTIMEFORMAT variable so that we have date/time stamps when using the `history` command
export HISTTIMEFORMAT='%D  %T  '

# Export LESS variable so that we can search man pages without being case sensitive and without losing the screen upon exit (Putty)
export LESS='iX'
